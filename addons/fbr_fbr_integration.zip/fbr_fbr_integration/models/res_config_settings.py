# -*- coding: utf-8 -*-
from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    # Use config_parameter so values auto-persist; no need for get_values/set_values
    fbr_di_base_url = fields.Char(
        string="FBR Base URL",
        help="e.g., https://gw.fbr.gov.pk (Prod) or http://localhost:5000 (Sandbox/Mock)",
        default="http://host.docker.internal:5000",
        config_parameter="fbr_di.base_url",
    )
    fbr_di_bearer_token = fields.Char(
        string="FBR Bearer Token",
        help="Bearer token if required by gateway",
        config_parameter="fbr_di.bearer_token",
    )
