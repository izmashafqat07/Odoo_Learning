from . import res_company
from . import res_config_settings
from . import uom_fbr
from . import product_template
from . import product_template_measures
from . import account_move
